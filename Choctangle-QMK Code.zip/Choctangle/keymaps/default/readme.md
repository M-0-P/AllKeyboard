# The default keymap for Choctangle
