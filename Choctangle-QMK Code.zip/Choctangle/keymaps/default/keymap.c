/* Copyright 2021 M0P
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include QMK_KEYBOARD_H

// Defines names for use in layer keycodes and the keymap

enum layers {
	_BAS = 0,
	_NUM = 1,
	_SYM = 2,
	_MOU = 3,
	_ACT = 4,
	_FUN = 5,
	_MAC = 6,
	_LCK = 7,
	_QMK = 8
};




enum my_keycodes {
  KY_APP1 = SAFE_RANGE,
  KY_APP2 = SAFE_RANGE + 0x1,
  KY_APP3 = SAFE_RANGE + 0x2,
  KY_APP4 = SAFE_RANGE + 0x3, 
  KY_APP5 = SAFE_RANGE + 0x4,
  KY_APP6 = SAFE_RANGE + 0x5,
  KY_WINL = SAFE_RANGE + 0x6,
  KY_WINR = SAFE_RANGE + 0x7,
  KY_CALC = SAFE_RANGE + 0x8,
  KY_SNIP = SAFE_RANGE + 0x9,
  KY_TASK = SAFE_RANGE + 0xA,
  KY_LOCK = SAFE_RANGE + 0xB,
  KY_SFHM = SAFE_RANGE + 0xC,
  KY_SFED = SAFE_RANGE + 0xD,
  KY_CLHM = SAFE_RANGE + 0xE,
  KY_CLED = SAFE_RANGE + 0xF,
  KY_CSHM = SAFE_RANGE + 0x10,
  KY_CSED = SAFE_RANGE + 0x11,
  KY_SLFT = SAFE_RANGE + 0x12,
  KY_SRGT = SAFE_RANGE + 0x13,
  KY_SFUP = SAFE_RANGE + 0x14,
  KY_SFDN = SAFE_RANGE + 0x15,
  KY_CTLT = SAFE_RANGE + 0x16,
  KY_CTRT = SAFE_RANGE + 0x17,
  KY_CSLT = SAFE_RANGE + 0x18,
  KY_CSRT = SAFE_RANGE + 0x19,
  KY_MACR = SAFE_RANGE + 0x1A,
  KY_LKCT = SAFE_RANGE + 0x1B,
  KY_LKAL = SAFE_RANGE + 0x1C, 
  KY_LKOM = SAFE_RANGE + 0x1D,
  KY_LKSF = SAFE_RANGE + 0x1E,  
  KY_TEST = SAFE_RANGE + 0x1F,
  KY_QODN = SAFE_RANGE + 0x20,
  KY_QOUP = SAFE_RANGE + 0x21,
  KY_QDDN = SAFE_RANGE + 0x22,
  KY_QDUP = SAFE_RANGE + 0x23,
  KY_QSDN = SAFE_RANGE + 0x24,
  KY_QSUP = SAFE_RANGE + 0x25,
  KY_QPDN = SAFE_RANGE + 0x26,
  KY_QPUP = SAFE_RANGE + 0x27,
  KY_QHSM = SAFE_RANGE + 0x28,
  KY_QHMC = SAFE_RANGE + 0x29,
  KY_QSAV = SAFE_RANGE + 0x2A,
  KY_QMON = SAFE_RANGE + 0x2B,
  KY_QKDN = SAFE_RANGE + 0x2C,
  KY_QKUP = SAFE_RANGE + 0x2D,
  KY_QRST = SAFE_RANGE + 0x30,
  KY_x = SAFE_RANGE + 0x80 + KC_X,
  KY_1 = SAFE_RANGE + 0x80 + KC_1,
  KY_2 = SAFE_RANGE + 0x80 + KC_2,
  KY_3 = SAFE_RANGE + 0x80 + KC_3,
  KY_4 = SAFE_RANGE + 0x80 + KC_4,
  KY_5 = SAFE_RANGE + 0x80 + KC_5,
  KY_6 = SAFE_RANGE + 0x80 + KC_6,
  KY_7 = SAFE_RANGE + 0x80 + KC_7,
  KY_8 = SAFE_RANGE + 0x80 + KC_8,
  KY_9 = SAFE_RANGE + 0x80 + KC_9,
  KY_0 = SAFE_RANGE + 0x80 + KC_0,
  KY_A = SAFE_RANGE + 0x80 + KC_A,
  KY_B = SAFE_RANGE + 0x80 + KC_B,
  KY_C = SAFE_RANGE + 0x80 + KC_C,
  KY_D = SAFE_RANGE + 0x80 + KC_D,
  KY_E = SAFE_RANGE + 0x80 + KC_E,
  KY_F = SAFE_RANGE + 0x80 + KC_F,
  KY_MINS = SAFE_RANGE + 0x80 + KC_MINS,
  KY_EQL = SAFE_RANGE + 0x80 + KC_EQL,
  KY_LBRC = SAFE_RANGE + 0x80 + KC_LBRC,
  KY_RBRC = SAFE_RANGE + 0x80 + KC_RBRC,
  KY_BSLS = SAFE_RANGE + 0x80 + KC_BSLS,
  KY_SCLN = SAFE_RANGE + 0x80 + KC_SCLN,
  KY_QUOT = SAFE_RANGE + 0x80 + KC_QUOT,
  KY_GRV = SAFE_RANGE + 0x80 + KC_GRV,
  KY_COMM = SAFE_RANGE + 0x80 + KC_COMM,
  KY_DOT = SAFE_RANGE + 0x80 + KC_DOT,
  KY_SLSH = SAFE_RANGE + 0x80 + KC_SLSH,
  KY_EXCL = SAFE_RANGE + 0x80 +0xFF+ KC_1,
  KY_AT = SAFE_RANGE + 0x80 +0xFF+ KC_2,
  KY_HASH = SAFE_RANGE + 0x80 +0xFF+ KC_3,
  KY_DOLR = SAFE_RANGE + 0x80 +0xFF+ KC_4,
  KY_PERC = SAFE_RANGE + 0x80 +0xFF+ KC_5,
  KY_CART = SAFE_RANGE + 0x80 +0xFF+ KC_6,
  KY_AMPR = SAFE_RANGE + 0x80 +0xFF+ KC_7,
  KY_STAR = SAFE_RANGE + 0x80 +0xFF+ KC_8,
  KY_LPAR = SAFE_RANGE + 0x80 +0xFF+ KC_9,
  KY_RPAR = SAFE_RANGE + 0x80 +0xFF+ KC_0,
  KY_UNDR = SAFE_RANGE + 0x80 +0xFF+ KC_MINS,
  KY_PLUS = SAFE_RANGE + 0x80 +0xFF+ KC_EQL,
  KY_LCBR = SAFE_RANGE + 0x80 +0xFF+ KC_LBRC,
  KY_RCBR = SAFE_RANGE + 0x80 +0xFF+ KC_RBRC,
  KY_PIPE = SAFE_RANGE + 0x80 +0xFF+ KC_BSLS,
  KY_COLN = SAFE_RANGE + 0x80 +0xFF+ KC_SCLN,
  KY_DQOT = SAFE_RANGE + 0x80 +0xFF+ KC_QUOT,
  KY_TILD = SAFE_RANGE + 0x80 +0xFF+ KC_GRV,
  KY_LTHN = SAFE_RANGE + 0x80 +0xFF+ KC_COMM,
  KY_GTHN = SAFE_RANGE + 0x80 +0xFF+ KC_DOT,
  KY_QUES = SAFE_RANGE + 0x80 +0xFF+ KC_SLSH  
};


const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    /* Base */
[_BAS] = LAYOUT(
         KC_ESC,         KC_DEL,           KC_Q,           KC_W,           KC_B,           KC_M,           KC_U,           KC_Y,        KC_BSPC,      MO(_LCK),    \
   	   TT(_QMK),	   TT(_FUN),           KC_D,           KC_L,           KC_R,           KC_H,           KC_I,           KC_O,       TT(_FUN),      TT(_MAC),   \
        KC_LGUI,         KC_TAB,           KC_T,           KC_F,           KC_S,           KC_N,           KC_A,           KC_E,         KC_ENT,       KC_LGUI, \
        KC_LALT,       TT(_ACT),           KC_K,           KC_P,           KC_J,           KC_G,        KY_SCLN,        KY_QUOT,       TT(_ACT),       KC_LALT, \
        KC_LCTL,       TT(_SYM),           KC_Z,           KC_X,           KC_C,           KC_V,        KY_COMM,         KY_DOT,       TT(_SYM),       KC_LCTL, \
       TT(_NUM),        KC_LSFT,                         KC_SPC,                       TT(_MOU),        KY_UNDR,                        KC_LSFT,       KC_CAPS  \
				),
[_NUM] = LAYOUT(
        _______,        _______,         KY_EQL,        KY_LPAR,        KY_RPAR,        KY_CART,        KY_PERC,           KY_x,        _______,        _______, \
   		_______,        _______,           KY_7,           KY_8,           KY_9,        KY_SLSH,           KY_A,           KY_B,        _______,        _______, \
        _______,        _______,           KY_4,           KY_5,           KY_6,        KY_STAR,           KY_C,           KY_D,        _______,        _______, \
        _______,        _______,           KY_1,           KY_2,           KY_3,        KY_MINS,           KY_E,           KY_F,        _______,        _______, \
        _______,        _______,           KY_0,        KY_COMM,         KY_DOT,        KY_PLUS,        KY_LTHN,        KY_GTHN,        _______,        _______, \
        _______,        _______,                        _______,                        _______,         KC_ENT,                        _______,        _______  \
				),
[_SYM] = LAYOUT(
        _______,        _______,          KY_AT,        KY_HASH,        KY_DOLR,        KY_CART,        KY_PERC,        KY_AMPR,        _______,        _______, \
   		_______,        _______,        KY_LCBR,        KY_RCBR,        XXXXXXX,        KY_SLSH,         KY_GRV,        KY_TILD,        _______,        _______, \
        _______,        _______,        KY_LTHN,        KY_GTHN,        XXXXXXX,        KY_STAR,        KC_BSLS,         KY_EQL,        _______,        _______, \
        _______,        _______,        KY_LPAR,        KY_RPAR,        XXXXXXX,        KY_MINS,        KY_COLN,        KY_DQOT,        _______,        _______, \
        _______,        _______,        KY_LBRC,        KY_RBRC,        KY_PIPE,        KY_PLUS,        KY_EXCL,        KY_QUES,        _______,        _______, \
        _______,        _______,                        _______,                        _______,      _______,                        _______,        _______  \
				),
[_MOU] = LAYOUT(
        _______,        _______,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        _______,        _______, \
   		_______,        _______,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        KC_MS_U,        XXXXXXX,        _______,        _______, \
        _______,        _______,        XXXXXXX,        XXXXXXX,        XXXXXXX,        KC_MS_L,        KC_MS_D,        KC_MS_R,        _______,        _______, \
        _______,        _______,        XXXXXXX,        LALT(LSFT(KC_UP)),        XXXXXXX,        KC_BTN1,        KC_WH_U,        KC_BTN2,        _______,        _______, \
        _______,        _______, LALT(LSFT(KC_LEFT)),        LALT(LSFT(KC_DOWN)),        LALT(LSFT(KC_RIGHT)),        XXXXXXX,        KC_WH_D,        XXXXXXX,        _______,        _______, \
        _______,        _______,                        XXXXXXX,                        _______,        XXXXXXX,                        _______,        _______  \
				),
[_ACT] = LAYOUT(
        _______,        _______,         KC_INS,       KC_PSCR,          KC_BRK,             KC_PGDN,             XXXXXXX,              KC_PGUP,        _______,        _______, \
   		_______,        _______,        XXXXXXX,   LSFT(KC_UP),         XXXXXXX,             XXXXXXX,               KC_UP,              XXXXXXX,        _______,        _______, \
        _______,        _______,  LSFT(KC_LEFT),  LSFT(KC_DOWN), LSFT(KC_RIGHT),             KC_LEFT,             KC_DOWN,             KC_RIGHT,        _______,        _______, \
        _______,        _______,        KC_HOME,  LSFT(KC_HOME),  LCTL(KC_HOME), LCTL(LSFT(KC_HOME)),       LCTL(KC_LEFT),       LCTL(KC_RIGHT),        _______,        _______, \
        _______,        _______,         KC_END,   LSFT(KC_END),   LCTL(KC_END),  LCTL(LSFT(KC_END)), LCTL(LSFT(KC_LEFT)), LCTL(LSFT(KC_RIGHT)),        _______,        _______, \
        _______,        _______,                        XXXXXXX,                             _______,             XXXXXXX,                              _______,        _______  \
				),
[_FUN] = LAYOUT(
        _______,        _______,                KC_F1,                KC_F2,          KC_F3,               KC_F4,               KC_F5,               KC_F6,        _______,        _______,  \
        _______,        _______,                KC_F7,                KC_F8,          KC_F9,              KC_F10,              KC_F11,              KC_F12,        _______,        _______, \
        _______,        _______,           LGUI(KC_1),           LGUI(KC_2),     LGUI(KC_3),          LGUI(KC_4),          LGUI(KC_5),          LGUI(KC_6),        _______,        _______, \
   		_______,        _______,        LGUI(KC_LEFT),       LGUI(KC_RIGHT),    LGUI(KC_UP),             KC_VOLD,             KC_VOLU,             KC_MUTE,        _______,        _______, \
        _______,        _______,   LGUI(LSFT(KC_LEFT)),LGUI(LSFT(KC_RIGHT)),  LGUI(KC_DOWN),    LGUI(LSFT(KC_S)),  LCTL(LSFT(KC_ESC)),  LCTL(LALT(KC_DEL)),        _______,        _______, \
        _______,        _______,                                    XXXXXXX,                             _______,             XXXXXXX,                             _______,        _______  \
				),
[_MAC] = LAYOUT(
        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR, \
   		KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        _______, \
        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR, \
        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR, \
        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR,        KY_MACR, \
        KY_MACR,        KY_MACR,                        KY_MACR,                        KY_MACR,        KY_MACR,                        KY_MACR,        KY_MACR  \
				),
[_LCK] = LAYOUT(
        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX, \
   		XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX, \
        KY_LKOM,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        KY_LKOM, \
        KY_LKAL,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        KY_LKAL, \
        KY_LKCT,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        KY_LKCT, \
        XXXXXXX,        KY_LKSF,                        XXXXXXX,                        XXXXXXX,        XXXXXXX,                        KY_LKSF,        _______  \
				),
[_QMK] = LAYOUT(
        _______,        XXXXXXX,        KY_QDDN,        KY_QDUP,        KY_QHSM,        KY_QMON,        KY_QSAV,        XXXXXXX,          RESET,        _______, \
   		_______,        XXXXXXX,        KY_QSDN,        KY_QSUP,        KY_QHMC,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        _______, \
        KY_QRST,        XXXXXXX,        KY_QODN,        KY_QOUP,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX, \
        XXXXXXX,        XXXXXXX,        KY_QPDN,        KY_QPUP,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX, \
        XXXXXXX,        XXXXXXX,        KY_QKDN,        KY_QKUP,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX,        XXXXXXX, \
        XXXXXXX,        XXXXXXX,                        XXXXXXX,                        XXXXXXX,        XXXXXXX,                        XXXXXXX,        XXXXXXX  \
				)
};


uint16_t mod_stat;


layer_state_t layer_state_set_user(layer_state_t state) {

int l = 0;
	
    switch (get_highest_layer(state)) {
		
        case _BAS:
			l = 0;
            break;
        case _NUM:
			l = 1;
            break;
        case _SYM:
			l = 2;
            break;
		case _MOU:
			l = 3;
			break;
        case _ACT:
			l = 4;
            break;
		case _FUN:
			l = 5;
            break;
		case _MAC:
			l = 6;
            break;
		case _LCK:
			l = 7;
            break;
		case _QMK:
			l = 8;
            break;

		
    }
	
	uprintf("AL%XZ\n", l);
    return state;
}


void led_set_user(uint8_t usb_led) {
  if (usb_led & (1<<USB_LED_CAPS_LOCK)) {
    //rgblight_setrgb_at(RGB_WHITE,1);
	uprintf("AC1Z\n");
  } else {
    //rgblight_setrgb_at(RGB_BLACK,1);
	uprintf("AC0Z\n");
  }
  
}
uint16_t mod_pressed = 0;
uint16_t ctrl_pressed = 0;
uint16_t alt_pressed = 0;
uint16_t oem_pressed = 0;
uint16_t shft_pressed = 0;

void lock_indicator(void)
{
	int s = ctrl_pressed + alt_pressed + oem_pressed+ shft_pressed;
	if(s >1){
		s = 5;
	}
	else if(ctrl_pressed == 1){
		s = 1;
	}
	else if(alt_pressed == 1){
		s = 2;
	}
	else if(oem_pressed == 1){
		s = 3;
	}
	else if(shft_pressed == 1){
		s = 4;
	}
	
	uprintf("AI0%XZ\n", s);
	
}


bool process_record_user(uint16_t keycode, keyrecord_t *record)
{
	//uprintf("hi");
// uprintf("KL: kc: %u, col: %u, row: %u, pressed: %u \n", keycode, record->event.key.col, record->event.key.row, record->event.pressed);
uprintf("AK%02X%02X%uZ\n", record->event.key.col, record->event.key.row, record->event.pressed);

  if(record->event.pressed && record->event.key.col == 1 && record->event.key.row == 0 &&(ctrl_pressed == 1 || alt_pressed == 1 || oem_pressed == 1 || shft_pressed == 1)){
	unregister_code(KC_LCTL);
	ctrl_pressed = 0;

	unregister_code(KC_LALT);
	alt_pressed = 0;

	unregister_code(KC_LGUI);
	oem_pressed = 0;
	
	unregister_code(KC_LSFT);
	shft_pressed = 0;

	  lock_indicator();
	  return false;
  }
  else if(keycode == KC_LCTL && ctrl_pressed == 1){
	unregister_code(KC_LCTL);
	ctrl_pressed = 0;
	lock_indicator();
	return false;
  }
  else if(keycode == KC_LALT && alt_pressed == 1){
	unregister_code(KC_LALT);
	alt_pressed = 0;
	lock_indicator();
	return false;
  }
  else if(keycode == KC_LGUI && oem_pressed == 1){
	unregister_code(KC_LGUI);
	oem_pressed = 0;
	lock_indicator();
	return false;
  }
  else if(keycode == KC_LSFT && shft_pressed == 1){
	unregister_code(KC_LSFT);
	shft_pressed = 0;
	lock_indicator();
	return false;
  }
  else if(keycode >= KY_LKCT && keycode <= KY_LKSF){
	  if(keycode == KY_LKCT){
		register_code(KC_LCTL);
		ctrl_pressed = 1;
	  }
	  if(keycode == KY_LKAL){
		register_code(KC_LALT);
		alt_pressed = 1;
	  }
	  if(keycode == KY_LKOM){
		register_code(KC_LGUI);
		oem_pressed = 1;
	  }
	  if(keycode == KY_LKSF){
		unregister_code(KC_LSFT);
		shft_pressed = 1;
	  }
	  lock_indicator();
	  return false;
  }
	  
  else if(keycode > SAFE_RANGE + 0x80 + 0xFF){
	  if(record->event.pressed){
        if((keyboard_report->mods & MOD_BIT (KC_LSFT)) || (keyboard_report->mods & MOD_BIT (KC_RSFT)))
        {
          register_code(keycode - (SAFE_RANGE + 0x80  + 0xFF));
          return false;
        }
        else
        {
		  register_code(KC_LSFT);
          register_code(keycode - (SAFE_RANGE + 0x80  + 0xFF));
		  mod_pressed = KC_LSFT;
		  return false;
        }
      }
      else
      {
          unregister_code(keycode - (SAFE_RANGE + 0x80  + 0xFF));
          if (mod_pressed != 0)
          {
            unregister_code(mod_pressed);
            mod_pressed = 0;
          }
		  return false;
      }
  }
	  else if (keycode > SAFE_RANGE + 0x80){
	  if(record->event.pressed)
      {
        if(keyboard_report->mods & MOD_BIT (KC_LSFT))
        {
          unregister_code(KC_LSFT);
          register_code(keycode - (SAFE_RANGE + 0x80));
          mod_pressed = KC_LSFT;
          return false;
        }
        else if(keyboard_report->mods & MOD_BIT (KC_RSFT))
        {
          unregister_code(KC_RSFT);
          register_code(keycode - (SAFE_RANGE + 0x80));
          mod_pressed = KC_RSFT;
          return false;
        }
        else
        {
          register_code(keycode - (SAFE_RANGE + 0x80));
		  return false;
        }
      }

      else 
      {
          unregister_code(keycode - (SAFE_RANGE + 0x80));
          if (mod_pressed != 0)
          {
            register_code(mod_pressed);
            mod_pressed = 0;
          }
		  return false;
      }
	  }
	  else if(keycode >= KY_QODN && keycode <= KY_QRST && record->event.pressed){
	  uprintf("AQ%XZ\n", keycode - (SAFE_RANGE));
	  }
	  else if((keycode == KY_MACR) && record->event.pressed){
		  uprintf("AM%X%02X%02XZ\n", get_highest_layer(layer_state), record->event.key.col, record->event.key.row);
		  return false;
	  }

	  
	  return true;
}


